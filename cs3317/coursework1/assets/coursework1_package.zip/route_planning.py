"""Coursework 1: Route Planning with Search Algorithms (Starter Code)

You only need to implement THREE algorithms:
  - dfs(...)
  - ucs(...)
  - astar(...)

BFS is provided as a worked example.

The rest of the file is minimal scaffolding for:
  - loading cities/roads
  - running one query from command line
  - producing a standalone HTML (SVG) visualization

Python: standard library only.
"""

from __future__ import annotations

import argparse
import heapq
import json
import math
import time
from collections import deque
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Set, Tuple

City = str


@dataclass(frozen=True)
class CityCoord:
    lat: float
    lon: float


@dataclass
class Result:
    algorithm: str
    start: City
    goal: City
    path: List[City]
    total_cost_km: float
    expanded_nodes: List[City]
    expanded_edges: List[Tuple[City, City]]
    runtime_ms: float
    output_html: str


# --------------------------
# Data loading / utilities
# --------------------------

def read_cities(path: Path) -> Dict[City, CityCoord]:
    """cities.txt: CityName latitude longitude

    """
    coords: Dict[City, CityCoord] = {}
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        name, lat_s, lon_s = line.split()
        coords[name] = CityCoord(float(lat_s), float(lon_s))
    return coords


def read_roads(path: Path) -> List[Tuple[City, City, float]]:
    """roads.txt: CityA CityB distance_km

    """
    roads: List[Tuple[City, City, float]] = []
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        a, b, d_s = line.split()
        roads.append((a, b, float(d_s)))
    return roads


def build_graph(roads: Iterable[Tuple[City, City, float]]) -> Dict[City, List[Tuple[City, float]]]:
    """Undirected weighted graph (adjacency list).

    Neighbors are sorted for deterministic traversal.
    """
    g: Dict[City, List[Tuple[City, float]]] = {}
    for a, b, d in roads:
        g.setdefault(a, []).append((b, d))
        g.setdefault(b, []).append((a, d))
    for u in g:
        g[u].sort(key=lambda x: x[0])
    return g


def haversine_km(a: CityCoord, b: CityCoord) -> float:
    """Great-circle distance (km) between lat/lon points."""
    R = 6371.0
    lat1, lon1 = math.radians(a.lat), math.radians(a.lon)
    lat2, lon2 = math.radians(b.lat), math.radians(b.lon)
    dlat = lat2 - lat1
    dlon = lon2 - lon1
    h = math.sin(dlat / 2) ** 2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon / 2) ** 2
    return 2 * R * math.asin(math.sqrt(h))


def reconstruct_path(parent: Dict[City, Optional[City]], start: City, goal: City) -> List[City]:
    if goal not in parent:
        return []
    cur: Optional[City] = goal
    out: List[City] = []
    while cur is not None:
        out.append(cur)
        cur = parent.get(cur)
    out.reverse()
    return out if out and out[0] == start else []


def path_cost_km(graph: Dict[City, List[Tuple[City, float]]], path: List[City]) -> float:
    if len(path) <= 1:
        return 0.0
    edge = {(u, v): w for u, nbrs in graph.items() for v, w in nbrs}
    return sum(edge[(path[i], path[i + 1])] for i in range(len(path) - 1))


# --------------------------
# Algorithms
# --------------------------

# BFS is provided as an example.

def bfs(graph: Dict[City, List[Tuple[City, float]]], start: City, goal: City):
    """Breadth-First Search (BFS).

    BFS explores the graph level-by-level:
      - First it expands all nodes 1 edge away from the start,
      - then all nodes 2 edges away,
      - and so on.

    Therefore, BFS guarantees the **fewest-hops** path (minimum number of edges),
    but it does **NOT** guarantee the minimum total distance on a weighted graph.

    Returns:
      path:           [start, ..., goal] (empty list if no path)
      expanded_nodes: nodes in the exact order they are expanded (popped from the queue)
      expanded_edges: directed edges (u, v) that were examined during expansion
    """

    # 1) FIFO queue: nodes are expanded in the same order they are discovered.
    #    We start by putting the start node in the queue.
    q = deque([start])

    # 2) visited: once a node is visited, we will not enqueue it again.
    #    This prevents infinite loops on graphs with cycles.
    visited: Set[City] = {start}

    # 3) parent pointers for path reconstruction:
    #    parent[child] = the node from which we first discovered 'child'.
    #    For the start node, parent is None.
    parent: Dict[City, Optional[City]] = {start: None}

    # For analysis/visualization:
    expanded_nodes: List[City] = []
    expanded_edges: List[Tuple[City, City]] = []

    # Main BFS loop
    while q:
        # Pop from the left => FIFO behavior
        u = q.popleft()

        # Record that we are expanding u now
        expanded_nodes.append(u)

        # If we reached the goal, we can stop early.
        # Because BFS expands by increasing hop-count, the first time we see 'goal'
        # (when popped) corresponds to the fewest-hops route.
        if u == goal:
            break

        # Expand neighbors in the stored (sorted) order for deterministic results.
        for v, _w in graph.get(u, []):
            # Record that the algorithm examined the edge u -> v.
            expanded_edges.append((u, v))

            # If we've seen v before, skip it.
            if v in visited:
                continue

            # Mark discovered
            visited.add(v)

            # Save parent pointer so we can reconstruct the path later.
            parent[v] = u

            # Enqueue for future expansion.
            q.append(v)

    # Reconstruct the final path (if goal was reached)
    path = reconstruct_path(parent, start, goal)
    return path, expanded_nodes, expanded_edges


def dfs(graph: Dict[City, List[Tuple[City, float]]], start: City, goal: City):
    """TODO: Implement Depth-First Search using an explicit stack.

    Returns: (path, expanded_nodes, expanded_edges)
    """
    # TODO: Student implementation starts here
    raise NotImplementedError


def ucs(graph: Dict[City, List[Tuple[City, float]]], start: City, goal: City):
    """TODO: Implement Uniform Cost Search (Dijkstra-like).

    Returns: (path, total_cost_km, expanded_nodes, expanded_edges)
    """
    # TODO: Student implementation starts here
    raise NotImplementedError


def astar(
    graph: Dict[City, List[Tuple[City, float]]],
    coords: Dict[City, CityCoord],
    start: City,
    goal: City,
):
    """TODO: Implement A* Search.

    Heuristic: h(n) = straight-line distance (km) from n to goal using coords.

    Returns: (path, total_cost_km, expanded_nodes, expanded_edges)
    """
    # TODO: Student implementation starts here
    raise NotImplementedError


# --------------------------
# Runner + visualization
# --------------------------

def run_one(
    algorithm: str,
    graph: Dict[City, List[Tuple[City, float]]],
    coords: Dict[City, CityCoord],
    start: City,
    goal: City,
):
    algo = algorithm.lower()

    t0 = time.perf_counter()
    if algo == "bfs":
        path, expanded_nodes, expanded_edges = bfs(graph, start, goal)
        total = path_cost_km(graph, path) if path else float("inf")
    elif algo == "dfs":
        path, expanded_nodes, expanded_edges = dfs(graph, start, goal)
        total = path_cost_km(graph, path) if path else float("inf")
    elif algo == "ucs":
        path, total, expanded_nodes, expanded_edges = ucs(graph, start, goal)
    elif algo == "astar":
        path, total, expanded_nodes, expanded_edges = astar(graph, coords, start, goal)
    else:
        raise ValueError("algorithm must be one of: bfs, dfs, ucs, astar")
    t1 = time.perf_counter()

    return path, total, expanded_nodes, expanded_edges, (t1 - t0) * 1000.0


def _normalize_edge(u: City, v: City) -> Tuple[City, City]:
    return (u, v) if u <= v else (v, u)


def save_visualization_html(
    coords: Dict[City, CityCoord],
    roads: List[Tuple[City, City, float]],
    algorithm: str,
    start: City,
    goal: City,
    path: List[City],
    expanded_nodes: List[City],
    expanded_edges: List[Tuple[City, City]],
    total_cost_km: float,
    runtime_ms: float,
    out_path: Path,
) -> None:
    """Standalone HTML (SVG) visualization."""

    lats = [c.lat for c in coords.values()]
    lons = [c.lon for c in coords.values()]
    min_lat, max_lat = min(lats), max(lats)
    min_lon, max_lon = min(lons), max(lons)

    width, height = 980, 720
    pad = 40

    def proj(city: City):
        c = coords[city]
        x = pad + (c.lon - min_lon) / (max_lon - min_lon) * (width - 2 * pad)
        y = pad + (max_lat - c.lat) / (max_lat - min_lat) * (height - 2 * pad)
        return x, y

    explored_u: Set[Tuple[City, City]] = {_normalize_edge(u, v) for (u, v) in expanded_edges}
    path_edges: Set[Tuple[City, City]] = set(_normalize_edge(path[i], path[i + 1]) for i in range(max(0, len(path) - 1)))

    road_lines = []
    for a, b, _d in roads:
        ax, ay = proj(a)
        bx, by = proj(b)
        e = _normalize_edge(a, b)
        cls = "edge"
        if e in explored_u:
            cls = "edge explored"
        if e in path_edges:
            cls = "edge path"
        road_lines.append(f'<line class="{cls}" x1="{ax:.2f}" y1="{ay:.2f}" x2="{bx:.2f}" y2="{by:.2f}" />')

    node_circles = []
    node_labels = []
    for city in sorted(coords.keys()):
        x, y = proj(city)
        cls = "node"
        if city == start:
            cls += " start"
        elif city == goal:
            cls += " goal"
        elif city in path:
            cls += " onpath"
        elif city in expanded_nodes:
            cls += " expanded"

        node_circles.append(f'<circle class="{cls}" cx="{x:.2f}" cy="{y:.2f}" r="6" />')

        # Keep labels inside the SVG viewBox (avoid clipping)
        label_dx = 8.0
        anchor = "start"
        if x > width - 90:
            label_dx = -8.0
            anchor = "end"
        label_x = x + label_dx
        label_y = y - 8.0
        if label_y < 14:
            label_y = y + 16.0

        node_labels.append(
            f'<text class="label" text-anchor="{anchor}" x="{label_x:.2f}" y="{label_y:.2f}">{city}</text>'
        )

    road_lines_svg = "\n      ".join(road_lines)
    node_circles_svg = "\n      ".join(node_circles)
    node_labels_svg = "\n      ".join(node_labels)

    meta = {
        "algorithm": algorithm,
        "start": start,
        "goal": goal,
        "path": path,
        "total_cost_km": total_cost_km,
        "expanded_nodes": len(expanded_nodes),
        "expanded_edges": len(expanded_edges),
        "runtime_ms": round(runtime_ms, 3),
    }

    html = f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Route Planning Visualization</title>
  <style>
    body {{ font-family: ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif; margin: 0; background: #ffffff; color: #111827; }}
    .wrap {{ max-width: 1100px; margin: 0 auto; padding: 18px 16px 28px; }}
    h1 {{ font-size: 18px; margin: 0 0 10px; }}
    .meta {{ display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 12px; }}
    .card {{ border: 1px solid #e5e7eb; border-radius: 10px; padding: 10px 12px; box-shadow: 0 1px 2px rgba(0,0,0,0.04); }}
    .kv {{ font-size: 13px; line-height: 1.5; }}
    .kv b {{ display: inline-block; width: 140px; color: #374151; }}
    svg {{ width: 100%; height: auto; border: 1px solid #e5e7eb; border-radius: 12px; background: #fbfdff; }}
    .edge {{ stroke: #cbd5e1; stroke-width: 2; }}
    .edge.explored {{ stroke: #60a5fa; stroke-width: 3; opacity: 0.9; }}
    .edge.path {{ stroke: #f97316; stroke-width: 4; opacity: 0.95; }}
    .node {{ fill: #334155; }}
    .node.expanded {{ fill: #2563eb; }}
    .node.onpath {{ fill: #f97316; }}
    .node.start {{ fill: #16a34a; r: 8; }}
    .node.goal {{ fill: #dc2626; r: 8; }}
    .label {{ font-size: 12px; fill: #0f172a; paint-order: stroke; stroke: rgba(255,255,255,0.85); stroke-width: 3px; }}
    .legend {{ display: flex; flex-wrap: wrap; gap: 10px; font-size: 12px; margin-top: 10px; color: #334155; }}
    .dot {{ width: 10px; height: 10px; border-radius: 99px; display: inline-block; margin-right: 6px; }}
    .ln {{ width: 18px; height: 0; border-top: 3px solid; display: inline-block; margin-right: 6px; vertical-align: middle; }}
    pre {{ background: #0b1220; color: #e5e7eb; padding: 10px 12px; border-radius: 10px; overflow: auto; }}
    code, pre {{ font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace; }}
  </style>
</head>
<body>
  <div class="wrap">
    <h1>Route Planning Visualization</h1>

    <div class="meta">
      <div class="card kv">
        <div><b>Algorithm</b> {algorithm}</div>
        <div><b>Start → Goal</b> {start} → {goal}</div>
        <div><b>Total cost (km)</b> {total_cost_km if math.isfinite(total_cost_km) else "INF"}</div>
        <div><b>Expanded nodes</b> {len(expanded_nodes)}</div>
        <div><b>Runtime (ms)</b> {runtime_ms:.3f}</div>
      </div>
      <div class="card">
        <div style="font-size:13px; font-weight:600; margin-bottom:6px;">Path</div>
        <div style="font-size:13px; line-height:1.5;">{(' → '.join(path) if path else '(no path found)')}</div>
      </div>
    </div>

    <svg viewBox="0 0 {width} {height}" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Graph visualization">
      {road_lines_svg}
      {node_circles_svg}
      {node_labels_svg}
    </svg>

    <div class="legend">
      <span><span class="ln" style="border-color:#cbd5e1"></span>Normal edge</span>
      <span><span class="ln" style="border-color:#60a5fa"></span>Explored edge</span>
      <span><span class="ln" style="border-color:#f97316"></span>Final path</span>
      <span><span class="dot" style="background:#16a34a"></span>Start</span>
      <span><span class="dot" style="background:#dc2626"></span>Goal</span>
      <span><span class="dot" style="background:#2563eb"></span>Expanded node</span>
    </div>

    <div class="card" style="margin-top:12px;">
      <div style="font-size:13px; font-weight:600; margin-bottom:6px;">Summary (JSON)</div>
      <pre>{json.dumps(meta, ensure_ascii=False, indent=2)}</pre>
    </div>
  </div>
</body>
</html>"""

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(html, encoding="utf-8")


def save_result_json(out_path: Path, result: Result) -> None:
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(asdict(result), ensure_ascii=False, indent=2), encoding="utf-8")


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Route planning (BFS/DFS/UCS/A*)")
    p.add_argument("--algorithm", required=True, choices=["bfs", "dfs", "ucs", "astar"])
    p.add_argument("--start", required=True)
    p.add_argument("--goal", required=True)
    p.add_argument("--cities", default="cities.txt")
    p.add_argument("--roads", default="roads.txt")
    p.add_argument("--output", default=str(Path("outputs") / "route_result.html"))
    p.add_argument("--save-json", default="", help="Optional: also save result.json")
    return p.parse_args()


def main() -> None:
    args = parse_args()
    root = Path(__file__).resolve().parent

    cities_path = root / args.cities if not Path(args.cities).is_absolute() else Path(args.cities)
    roads_path = root / args.roads if not Path(args.roads).is_absolute() else Path(args.roads)

    coords = read_cities(cities_path)
    roads = read_roads(roads_path)
    graph = build_graph(roads)

    if args.start not in coords or args.goal not in coords:
        raise SystemExit(f"Unknown city. start={args.start} goal={args.goal}")

    path, total, expanded_nodes, expanded_edges, runtime_ms = run_one(
        args.algorithm, graph, coords, args.start, args.goal
    )

    out_html = Path(args.output)
    out_html = out_html if out_html.is_absolute() else (root / out_html)

    save_visualization_html(
        coords=coords,
        roads=roads,
        algorithm=args.algorithm,
        start=args.start,
        goal=args.goal,
        path=path,
        expanded_nodes=expanded_nodes,
        expanded_edges=expanded_edges,
        total_cost_km=total,
        runtime_ms=runtime_ms,
        out_path=out_html,
    )

    result = Result(
        algorithm=args.algorithm,
        start=args.start,
        goal=args.goal,
        path=path,
        total_cost_km=total,
        expanded_nodes=expanded_nodes,
        expanded_edges=expanded_edges,
        runtime_ms=round(runtime_ms, 3),
        output_html=str(out_html),
    )

    if args.save_json:
        out_json = Path(args.save_json)
        out_json = out_json if out_json.is_absolute() else (root / out_json)
        save_result_json(out_json, result)

    print(f"Algorithm: {result.algorithm}")
    print(f"Query: {result.start} -> {result.goal}")
    print(f"Path: {(' -> '.join(result.path) if result.path else '(no path)')}")
    print(f"Total cost (km): {result.total_cost_km}")
    print(f"Expanded nodes: {len(result.expanded_nodes)}")
    print(f"Runtime (ms): {result.runtime_ms}")
    print(f"Visualization: {result.output_html}")


if __name__ == "__main__":
    main()
