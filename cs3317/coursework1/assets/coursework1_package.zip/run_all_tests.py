"""Automated test runner for Coursework 1.

This script runs ALL algorithms on the required queries and stores results in
an output directory. Students should submit that directory as part of their
submission.

Usage:
  python run_all_tests.py
  python run_all_tests.py --outdir submission_results

Outputs (inside outdir/):
  summary.json
  summary.csv
  <ALGO>/<START>_to_<GOAL>/result.json
  <ALGO>/<START>_to_<GOAL>/visualization.html

Notes:
  - This script imports route_planning.py from the same folder.
  - It will work after students complete the TODO algorithm functions.
"""

from __future__ import annotations

import argparse
import csv
import json
import time
import traceback
from pathlib import Path
from typing import Dict, List, Tuple

import route_planning as rp

# NOTE: route_planning.py provides BFS and scaffolding.
# Students implement DFS/UCS/A*; this runner calls into their code.


REQUIRED_QUERIES: List[Tuple[str, str]] = [
    ("Beijing", "Shanghai"),
    ("Beijing", "Shenzhen"),
    ("Shanghai", "Chengdu"),
    ("Guangzhou", "XiAn"),
    ("Chengdu", "Hangzhou"),
]

ALGORITHMS = ["bfs", "dfs", "ucs", "astar"]


def safe_name(s: str) -> str:
    return s.replace(" ", "_")


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Run required tests for all algorithms")
    p.add_argument(
        "--outdir",
        default="test_results",
        help="Output directory to store results (default: ./test_results)",
    )
    p.add_argument("--cities", default="cities.txt", help="Path to cities.txt")
    p.add_argument("--roads", default="roads.txt", help="Path to roads.txt")
    return p.parse_args()


def main() -> None:
    args = parse_args()
    root = Path(__file__).resolve().parent

    cities_path = (root / args.cities).resolve() if not Path(args.cities).is_absolute() else Path(args.cities)
    roads_path = (root / args.roads).resolve() if not Path(args.roads).is_absolute() else Path(args.roads)

    coords = rp.read_cities(cities_path)
    roads = rp.read_roads(roads_path)
    graph = rp.build_graph(roads)

    out_root = Path(args.outdir)
    if not out_root.is_absolute():
        out_root = root / out_root
    out_root.mkdir(parents=True, exist_ok=True)

    summary_rows: List[Dict[str, object]] = []

    for algo in ALGORITHMS:
        for start, goal in REQUIRED_QUERIES:
            case_dir = out_root / algo / f"{safe_name(start)}_to_{safe_name(goal)}"
            case_dir.mkdir(parents=True, exist_ok=True)
            out_html = case_dir / "visualization.html"
            out_json = case_dir / "result.json"

            row: Dict[str, object] = {
                "algorithm": algo,
                "start": start,
                "goal": goal,
                "ok": False,
                "runtime_ms": None,
                "total_cost": None,
                "path": None,
                "path_length": None,
                "expanded_nodes": None,
                "expanded_edges": None,
                "result_json": str(out_json.relative_to(out_root)),
                "visualization_html": str(out_html.relative_to(out_root)),
                "error": None,
            }

            try:
                path, total, expanded_nodes, expanded_edges, runtime_ms = rp.run_one(
                    algo, graph, coords, start, goal
                )

                rp.save_visualization_html(
                    coords=coords,
                    roads=roads,
                    algorithm=algo,
                    start=start,
                    goal=goal,
                    path=path,
                    expanded_nodes=expanded_nodes,
                    expanded_edges=expanded_edges,
                    total_cost_km=total,
                    runtime_ms=runtime_ms,
                    out_path=out_html,
                )

                result_obj = rp.Result(
                    algorithm=algo,
                    start=start,
                    goal=goal,
                    path=path,
                    total_cost_km=total,
                    expanded_nodes=expanded_nodes,
                    expanded_edges=expanded_edges,
                    runtime_ms=round(runtime_ms, 3),
                    output_html=str(out_html),
                )
                rp.save_result_json(out_json, result_obj)

                row["ok"] = True
                row["runtime_ms"] = round(runtime_ms, 3)
                row["total_cost"] = total
                row["path"] = " -> ".join(path) if path else ""
                row["path_length"] = len(path)
                row["expanded_nodes"] = len(expanded_nodes)
                row["expanded_edges"] = len(expanded_edges)
            except Exception as e:
                row["error"] = f"{type(e).__name__}: {e}"
                # Save traceback for debugging
                (case_dir / "traceback.txt").write_text(traceback.format_exc(), encoding="utf-8")

            summary_rows.append(row)

    # Write summary.json
    (out_root / "summary.json").write_text(json.dumps(summary_rows, ensure_ascii=False, indent=2), encoding="utf-8")

    # Write summary.csv
    fieldnames = [
        "algorithm",
        "start",
        "goal",
        "ok",
        "runtime_ms",
        "total_cost",
        "path",
        "path_length",
        "expanded_nodes",
        "expanded_edges",
        "result_json",
        "visualization_html",
        "error",
    ]
    with (out_root / "summary.csv").open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for r in summary_rows:
            w.writerow(r)

    print(f"Done. Results written to: {out_root}")


if __name__ == "__main__":
    main()
