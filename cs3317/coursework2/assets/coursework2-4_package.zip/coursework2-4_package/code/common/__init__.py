"""
Common utilities shared across all three courseworks.

Modules:
    data_loader: Data loading, batching, and train/val splitting
    metrics: Classification metrics (accuracy, precision, recall, F1, confusion matrix)
    visualization: Plotting utilities for training curves, confusion matrices, etc.
    utils: Seed setting, timing, early stopping, and result saving
"""
