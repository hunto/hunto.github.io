"""
Configuration for CW2: Logistic Regression.

Default hyperparameters are provided. You can override them via command-line
arguments in run.py (e.g., python run.py --learning_rate 0.001).
"""

from dataclasses import dataclass


@dataclass
class Config:
    # Data
    data_dir: str = "../data/fashionmnist"
    val_ratio: float = 0.1

    # Loss function: "cross_entropy" | "hinge" | "exponential" | "squared"
    loss_type: str = "cross_entropy"

    # Training
    learning_rate: float = 0.1
    batch_size: int = 128
    num_epochs: int = 30
    seed: int = 42

    # Regularization (bonus)
    regularization: float = 0.0  # L2 regularization strength

    # Output
    output_dir: str = "outputs"

    # Quick mode: use a subset of training data for fast debugging
    quick: bool = False
    quick_num_samples: int = 10000
    quick_epochs: int = 10
