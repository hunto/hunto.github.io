"""
Configuration for CW3: Multi-Layer Perceptron.

Default hyperparameters are provided. Override via command-line in run.py.
"""

from dataclasses import dataclass, field
from typing import List


@dataclass
class Config:
    # Data
    data_dir: str = "../data/fashionmnist"
    val_ratio: float = 0.1

    # Model architecture
    hidden_dims: List[int] = field(default_factory=lambda: [128, 64])
    activation: str = "relu"  # "relu" | "sigmoid"

    # Training
    learning_rate: float = 0.01
    momentum: float = 0.9
    weight_decay: float = 0.0
    batch_size: int = 128
    num_epochs: int = 30
    seed: int = 42

    # Output
    output_dir: str = "outputs"

    # Quick mode
    quick: bool = False
    quick_num_samples: int = 10000
    quick_epochs: int = 10
