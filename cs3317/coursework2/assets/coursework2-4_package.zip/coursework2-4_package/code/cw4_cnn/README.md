# Coursework 4: Convolutional Neural Network

## Objective

Implement CNN architectures using PyTorch for FashionMNIST classification. Compare CNN performance with CW2 (logistic regression) and CW3 (MLP), and understand why CNNs excel at image tasks.

## Connection to CW2 & CW3

| CW | What you did | What PyTorch does for you |
|---|---|---|
| CW2 | Manual gradient computation (`dW = X.T @ grad`) | `loss.backward()` |
| CW3 | Manual backpropagation (chain of `layer.backward()`) | `loss.backward()` |
| CW4 | Define architecture only | PyTorch autograd handles everything! |

**Key insight**: `loss.backward()` in PyTorch automatically does what you built by hand in CW3 — propagating gradients through all layers via the chain rule.

## What You Need to Implement

| File | What to implement |
|---|---|
| `model.py` | `SimpleCNN.__init__()`, `SimpleCNN.forward()`, `DeepCNN.__init__()` (bonus), `DeepCNN.forward()` (bonus) |

## How to Run

```bash
cd cw4_cnn

# Quick mode (for debugging)
python run.py --quick

# Train SimpleCNN
python run.py

# Train with data augmentation
python run.py --use_augmentation

# Train DeepCNN (bonus)
python run.py --model_type deep_cnn --num_epochs 20

# Different optimizer
python run.py --optimizer_type sgd --learning_rate 0.01

# Run shape checks
python -m tests.test_cw4
```

## How to Verify Your Implementation

1. Run `python -m tests.test_cw4` — shape checks and gradient flow should pass
2. Run `python run.py` — SimpleCNN should reach ~90% test accuracy
3. Your CNN should outperform both CW2 and CW3

## Deliverables

1. **Code**: Completed `model.py`
2. **Report** (use the template in `../../report_template/`, see example in `../../report_examples/cw4_example_report.pdf`):
   - CNN architecture description and design choices
   - Hyperparameter exploration
   - Cross-coursework comparison (CW2 vs CW3 vs CW4)

## Grading Rubric (100 points)

| Component | Points | Criteria |
|---|---|---|
| SimpleCNN architecture | 20 | Valid conv/pool/fc layers, correct shapes |
| Forward pass | 10 | Correct sequential computation |
| Training convergence | 15 | SimpleCNN >= 90% test accuracy |
| DeepCNN / advanced architecture | 15 | BatchNorm/Dropout/residual; >= 92% |
| Data augmentation | 5 | Implements and reports augmentation effect |
| Hyperparameter exploration report | 15 | Optimizer, LR, architecture exploration with curves |
| Cross-CW comparison | 10 | Compares LR vs MLP vs CNN; discusses spatial structure |
| Code quality | 10 | Proper nn.Module, device handling |

**Bonus (up to +10):** LR scheduler (+3), model ensembling (+4), filter visualization (+3)
