"""
Configuration for CW4: Convolutional Neural Network.

Default hyperparameters are provided. Override via command-line in run.py.
"""

from dataclasses import dataclass


@dataclass
class Config:
    # Data
    data_dir: str = "../data"
    val_ratio: float = 0.1
    num_workers: int = 2

    # Model
    model_type: str = "simple_cnn"  # "simple_cnn" | "deep_cnn"

    # Training
    learning_rate: float = 0.001
    optimizer_type: str = "adam"  # "adam" | "sgd"
    batch_size: int = 64
    num_epochs: int = 15
    seed: int = 42

    # Augmentation
    use_augmentation: bool = False

    # Output
    output_dir: str = "outputs"

    # Quick mode
    quick: bool = False
    quick_epochs: int = 3
