# CS3317 Final Project — Self-Evaluation Kit

A small, dependency-light kit (numpy only) for **evaluating your own
submissions offline**, now that the competition is over. It includes the
**hidden test answer key**, so you can reproduce your exact leaderboard score
on your own machine.

The scorer reproduces the leaderboard metric **exactly**: F1-macro is primary,
F1-micro secondary, probabilities are thresholded with a strict `p > 0.5`,
`example_id`s missing from your prediction are filled with 0.5 (abstain), and
extra ids are ignored.

> **Note on the released labels.** `test_labels.csv` contains the *anonymized*
> labels (the 18-dim multi-hot vectors `label_0..label_17`) for the 2,000 test
> examples. It does **not** reveal what each integer label means (the genre
> mapping) or which movie each example is — those stay private. The labels are
> released only so you can reproduce and keep experimenting with leaderboard
> scores after the course.

---

## 1. Reproduce your exact leaderboard score

```bash
pip install numpy
python score.py --truth test_labels.csv --pred your_submission.csv
```

`your_submission.csv` is any leaderboard-format file
(`example_id,label_0,…,label_17`, all 2,000 test rows). The printed F1-macro
matches what the leaderboard reported, to the decimal — and you also get a
**per-mask-subset breakdown** (intact / image-missing / text-missing), the
same stratified view the leaderboard uses, so you can see where your
robustness is weakest.

Add `--per-class` for the per-label F1 breakdown.

## 2. Try new ideas against the validation split

While iterating, you can also score against the clean `val` split (labels are
already in the bundle):

```bash
python score.py --truth /path/to/student_bundle/data/val.csv --pred my_val_preds.csv
```

## 3. Simulate the modality dropout locally

`val` is clean, but the hidden test zeroes one modality on ~30% of examples.
To get a `val`-based estimate that mimics that distribution:

```bash
python make_local_testset.py --bundle /path/to/student_bundle
# -> localtest/  (localtest.csv + 3 zeroed .npz + localtest_truth.csv)
python score.py --truth localtest/localtest_truth.csv --pred localtest_preds.csv
```

## 4. Practice sandbox leaderboard (optional, online)

If you'd rather submit online, a **practice leaderboard** is open with
**unlimited submissions**:

> **http://taohuang.info:13317/**

It scores against the same hidden test. It is a **practice sandbox, separate
from the official (closed) board; results do not affect any grade.**

Questions: **Dr. Tao Huang — t.huang@sjtu.edu.cn**.

---

## Files

```
selfeval/
├── README.md                 this file
├── evaluate.py               F1-macro / F1-micro (identical to the leaderboard)
├── score.py                  CLI scorer: --truth <labels.csv> --pred <preds.csv>
├── make_local_testset.py     build a hidden-test-like local proxy from val
└── test_labels.csv           hidden-test answer key: example_id, label_0..17, has_image, has_text
```
