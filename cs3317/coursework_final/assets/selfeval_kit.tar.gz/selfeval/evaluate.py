"""Multi-label F1-macro / F1-micro — identical to the leaderboard's metric.

Pure numpy. A class with no positives and no predictions contributes F1 = 0
to the macro average (matches scikit-learn's default zero_division=0).
"""
from __future__ import annotations

import numpy as np


def f1_macro_micro(y_true: np.ndarray, y_pred: np.ndarray) -> tuple[float, float]:
    if y_true.shape != y_pred.shape:
        raise ValueError(f"shape mismatch: {y_true.shape} vs {y_pred.shape}")
    yt = y_true.astype(bool)
    yp = y_pred.astype(bool)
    tp = (yt & yp).sum(axis=0).astype(np.int64)
    fp = (~yt & yp).sum(axis=0).astype(np.int64)
    fn = (yt & ~yp).sum(axis=0).astype(np.int64)
    denom = 2 * tp + fp + fn
    f1_per_class = np.where(denom > 0, 2 * tp / np.maximum(denom, 1), 0.0)
    f1_macro = float(f1_per_class.mean())
    tp_s, fp_s, fn_s = int(tp.sum()), int(fp.sum()), int(fn.sum())
    md = 2 * tp_s + fp_s + fn_s
    f1_micro = (2 * tp_s) / md if md > 0 else 0.0
    return f1_macro, float(f1_micro)


def per_class_f1(y_true: np.ndarray, y_pred: np.ndarray) -> np.ndarray:
    yt = y_true.astype(bool)
    yp = y_pred.astype(bool)
    tp = (yt & yp).sum(axis=0).astype(np.int64)
    fp = (~yt & yp).sum(axis=0).astype(np.int64)
    fn = (yt & ~yp).sum(axis=0).astype(np.int64)
    denom = 2 * tp + fp + fn
    return np.where(denom > 0, 2 * tp / np.maximum(denom, 1), 0.0)
