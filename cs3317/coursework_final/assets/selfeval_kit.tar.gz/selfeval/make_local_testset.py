"""Build a local test proxy from the validation split, with the SAME kind of
test-time modality dropout the hidden test uses (~30% of examples have one
modality zeroed). This lets you estimate hidden-test behaviour offline.

It reads the bundle's clean validation split:
    <bundle>/data/val.csv
    <bundle>/data/val_image.npz
    <bundle>/data/val_text_CLIP.npz
    <bundle>/data/val_text_BERT.npz
and writes, under ./localtest/:
    localtest.csv            example_id, text_raw, has_image, has_text   (predict on THIS)
    localtest_image.npz      'features' (image rows zeroed where has_image=0)
    localtest_text_CLIP.npz  'features' (text rows zeroed where has_text=0)
    localtest_text_BERT.npz  'features' (text rows zeroed where has_text=0)
    localtest_truth.csv      example_id, label_0..17, has_image, has_text  (PRIVATE — for scoring)

Workflow:
    python make_local_testset.py --bundle /path/to/student_bundle
    #   train on train.csv, predict on localtest.* -> localtest_preds.csv
    python score.py --truth localtest/localtest_truth.csv --pred localtest_preds.csv

The split is deterministic (seed) so the proxy is stable across runs.
"""
from __future__ import annotations

import argparse
import csv
from pathlib import Path

import numpy as np

N_CLASSES = 18
LABEL_COLS = [f"label_{i}" for i in range(N_CLASSES)]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--bundle", type=Path, default=Path(".."),
                    help="path to the extracted student_bundle (contains data/)")
    ap.add_argument("--out", type=Path, default=Path("localtest"))
    ap.add_argument("--p-image-missing", type=float, default=0.15)
    ap.add_argument("--p-text-missing", type=float, default=0.15)
    ap.add_argument("--seed", type=int, default=3317)
    args = ap.parse_args()

    data = args.bundle / "data"
    val_csv = data / "val.csv"
    if not val_csv.exists():
        raise SystemExit(f"[error] {val_csv} not found — pass --bundle <path to student_bundle>")

    rows = list(csv.DictReader(open(val_csv, newline="", encoding="utf-8")))
    n = len(rows)
    fi = np.load(data / "val_image.npz")["features"].astype(np.float32)
    fc = np.load(data / "val_text_CLIP.npz")["features"].astype(np.float32)
    fb = np.load(data / "val_text_BERT.npz")["features"].astype(np.float32)
    assert fi.shape[0] == fc.shape[0] == fb.shape[0] == n, "feature/CSV row mismatch"

    rng = np.random.default_rng(args.seed)
    u = rng.random(n)
    has_image = np.ones(n, dtype=int)
    has_text = np.ones(n, dtype=int)
    drop_img = u < args.p_image_missing
    drop_txt = (u >= args.p_image_missing) & (u < args.p_image_missing + args.p_text_missing)
    has_image[drop_img] = 0
    has_text[drop_txt] = 0

    fi2, fc2, fb2 = fi.copy(), fc.copy(), fb.copy()
    fi2[drop_img] = 0.0
    fc2[drop_txt] = 0.0
    fb2[drop_txt] = 0.0

    args.out.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(args.out / "localtest_image.npz", features=fi2)
    np.savez_compressed(args.out / "localtest_text_CLIP.npz", features=fc2)
    np.savez_compressed(args.out / "localtest_text_BERT.npz", features=fb2)

    with open(args.out / "localtest.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["example_id", "text_raw", "has_image", "has_text"])
        for i, r in enumerate(rows):
            txt = "" if has_text[i] == 0 else r.get("text_raw", "")
            w.writerow([r["example_id"], txt, has_image[i], has_text[i]])

    with open(args.out / "localtest_truth.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["example_id"] + LABEL_COLS + ["has_image", "has_text"])
        for i, r in enumerate(rows):
            w.writerow([r["example_id"]] + [r[c] for c in LABEL_COLS]
                       + [has_image[i], has_text[i]])

    n_img = int((has_image == 0).sum())
    n_txt = int((has_text == 0).sum())
    print(f"wrote {args.out}/  ({n} examples)")
    print(f"  intact={n - n_img - n_txt}  image-missing={n_img}  text-missing={n_txt}")
    print(f"  predict on localtest.* then: python score.py "
          f"--truth {args.out}/localtest_truth.csv --pred your_preds.csv")


if __name__ == "__main__":
    main()
