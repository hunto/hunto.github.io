"""Score a prediction CSV against a ground-truth CSV — locally, offline.

Reproduces the CS3317 leaderboard metric EXACTLY:
  - F1-macro is the primary metric, F1-micro secondary.
  - Probabilities are thresholded with a STRICT  p > threshold  (default 0.5),
    so exactly-0.5 entries count as negative — same as the leaderboard.
  - example_ids missing from the prediction are filled with 0.5 (abstain).
  - example_ids in the prediction but not in the truth are ignored.

If the truth CSV has `has_image` / `has_text` columns (e.g. the local test
proxy from make_local_testset.py), a per-mask-subset breakdown is also printed
— intact / image-missing / text-missing — mirroring the leaderboard's
stratified view.

Usage:
    # against the bundle's clean validation split
    python score.py --truth ../data/val.csv --pred my_val_preds.csv

    # against a simulated local test (with the modality dropout applied)
    python make_local_testset.py --bundle ..        # writes localtest/
    #   ... train on train, predict on localtest, write localtest_preds.csv ...
    python score.py --truth localtest/localtest_truth.csv --pred localtest_preds.csv
"""
from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path

import numpy as np

from evaluate import f1_macro_micro, per_class_f1

N_CLASSES = 18
LABEL_COLS = [f"label_{i}" for i in range(N_CLASSES)]


def _read_truth(path: Path):
    """Returns (labels_dict, mask_dict_or_None). labels_dict: eid -> [int]*18.
    mask_dict: eid -> (has_image, has_text) if those columns exist."""
    labels: dict[str, list[int]] = {}
    masks: dict[str, tuple[int, int]] = {}
    with open(path, newline="", encoding="utf-8") as f:
        r = csv.DictReader(f)
        cols = r.fieldnames or []
        if "example_id" not in cols or any(c not in cols for c in LABEL_COLS):
            sys.exit(f"[error] {path} must have columns example_id, label_0..label_17")
        has_mask = "has_image" in cols and "has_text" in cols
        for row in r:
            eid = row["example_id"].strip()
            labels[eid] = [int(float(row[c])) for c in LABEL_COLS]
            if has_mask:
                masks[eid] = (int(float(row["has_image"])), int(float(row["has_text"])))
    return labels, (masks if masks else None)


def _read_pred(path: Path) -> dict[str, list[float]]:
    preds: dict[str, list[float]] = {}
    with open(path, newline="", encoding="utf-8") as f:
        r = csv.reader(f)
        header = [h.strip() for h in next(r)]
        expected = ["example_id"] + LABEL_COLS
        if header != expected:
            sys.exit(f"[error] prediction header must be exactly:\n  {','.join(expected)}\n"
                     f"got:\n  {','.join(header)}")
        for i, row in enumerate(r, 2):
            if len(row) != len(expected):
                continue
            eid = row[0].strip()
            try:
                vals = [min(1.0, max(0.0, float(v))) for v in row[1:]]
            except ValueError:
                continue
            preds[eid] = vals
    return preds


def _score(eids, labels, preds, threshold):
    n = len(eids)
    P = np.full((n, N_CLASSES), 0.5, dtype=np.float32)
    Y = np.zeros((n, N_CLASSES), dtype=np.int8)
    n_missing = 0
    for i, eid in enumerate(eids):
        Y[i] = labels[eid]
        if eid in preds:
            P[i] = preds[eid]
        else:
            n_missing += 1
    pred_bin = (P > threshold).astype(np.int8)
    f1m, f1mi = f1_macro_micro(Y, pred_bin)
    return f1m, f1mi, pred_bin, Y, n_missing


def main():
    ap = argparse.ArgumentParser(description="Offline scorer (matches the CS3317 leaderboard metric).")
    ap.add_argument("--truth", required=True, type=Path, help="CSV with example_id + label_0..17 (+ optional mask cols)")
    ap.add_argument("--pred", required=True, type=Path, help="prediction CSV: example_id + label_0..17")
    ap.add_argument("--threshold", type=float, default=0.5)
    ap.add_argument("--per-class", action="store_true", help="also print per-class F1")
    args = ap.parse_args()

    labels, masks = _read_truth(args.truth)
    preds = _read_pred(args.pred)
    eids = sorted(labels)

    extras = set(preds) - set(labels)
    f1m, f1mi, pred_bin, Y, n_missing = _score(eids, labels, preds, args.threshold)

    print(f"\n  examples scored : {len(eids)}")
    if n_missing:
        print(f"  missing in pred : {n_missing}  (filled with 0.5 = abstain)")
    if extras:
        print(f"  ignored extras  : {len(extras)}  (ids not in truth)")
    print(f"  threshold       : {args.threshold}  (strict p > t)")
    print(f"\n  F1-macro  = {f1m:.4f}   <- primary metric")
    print(f"  F1-micro  = {f1mi:.4f}")

    if masks:
        groups = {"intact (1,1)": (1, 1), "image-missing (0,1)": (0, 1), "text-missing (1,0)": (1, 0)}
        print("\n  per-mask-subset F1-macro:")
        for name, m in groups.items():
            sub = [e for e in eids if masks.get(e) == m]
            if not sub:
                continue
            fm, _, _, _, _ = _score(sub, labels, preds, args.threshold)
            print(f"    {name:22s} N={len(sub):>4d}   F1-macro={fm:.4f}")

    if args.per_class:
        pc = per_class_f1(Y, pred_bin)
        print("\n  per-class F1:")
        for i, v in enumerate(pc):
            print(f"    label_{i:<2d} {v:.4f}")
    print()


if __name__ == "__main__":
    main()
